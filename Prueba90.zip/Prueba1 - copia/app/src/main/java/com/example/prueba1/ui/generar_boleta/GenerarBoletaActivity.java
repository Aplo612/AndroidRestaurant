package com.example.prueba1.ui.generar_boleta;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.prueba1.R;

public class GenerarBoletaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_generar_boleta);
    }
}