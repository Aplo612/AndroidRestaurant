package com.example.prueba1.ui.generar_pedidos;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.prueba1.R;

public class GenerarPedidosViewModel extends ViewModel {





    public GenerarPedidosViewModel() {

    }
}